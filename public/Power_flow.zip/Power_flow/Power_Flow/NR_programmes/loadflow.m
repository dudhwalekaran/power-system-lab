clear all;
t0=clock;
convergence_bit=0;    % this bit will be set to 1 if convergence is reached.
%----------------------------------Load the system data--------------------------%
load busno.dat;
load nt.dat;
load pvpq.dat;
%--------------------------------------------------------------------------------%
sl=busno(1);
tole=busno(2);
nb=busno(3);
nline=busno(4);
ntrans=busno(5);
npv=busno(6);
Q_bit=busno(7);
npq=busno(8);                                                                                                                                                                          
nshunt=busno(9);
Vsl=busno(10);
if (nshunt~=0)
  load shunt.dat;
end   
if (Q_bit~=0)
  load Qlim_data.dat;
end 

pv_data=pvpq(1:npv,:);      %P-V bus data
load_data=pvpq(npv+1:npv+npq,:); % load data
pq_data = load_data((load_data(:,1)~=sl),:);  %P-Q bus data

pv=sparse(zeros(nb,1));
pq=sparse(zeros(nb,1));
pv(pv_data(:,1))=pv_data(:,1);
pq(pq_data(:,1))=pq_data(:,1);
pvpq_buses=pq(pv==pq);   
pvpq_buses((pvpq_buses==0),:)=[]; %pvpq bus nos


sl_load=sparse(zeros(1,3));
if(sum(pvpq(:,1)==sl)==1)
  sl_load=pvpq((pvpq(:,1)==sl),:);   %slack bus load data
end


num_nosl = [1:nb]';
num_nosl(sl,:) = [];                                                      
%------------------------call ybus_form.m  to construct the YBUS-----------%
ybus_form;       
%--------------------------------------------------------------------------%
Psp = sparse(zeros(nb,1));
Psp(pv_data(:,1)) = pv_data(:,3);
Psp(pq_data(:,1)) = Psp(pq_data(:,1))-pq_data(:,2);
Qsp = sparse(zeros(nb,1));
Qsp(pq_data(:,1)) = -pq_data(:,3);

pv_Vmag =sparse(zeros(nb,1));
pv_Vmag(pv_data(:,1))= pv_data(:,2);

Qload =sparse(zeros(nb,1));
Qload(pq_data(:,1))= pq_data(:,3);

if (Q_bit~=0)
  QLlim = sparse(zeros(nb,1)); 
  QUlim = sparse(zeros(nb,1));
  QLlim(pv_data(:,1))=-9999;
  QUlim(pv_data(:,1))=9999;
  QUlim(Qlim_data(:,1)) = Qlim_data(:,3); 
  QLlim(Qlim_data(:,1)) = Qlim_data(:,2);          
end
%-----------------call jacob_form.m to obtain the bus voltages----------%

jacob_form

%-------------------perform the power flow calculations----------------%

powerflow;     

%-------------------prepare the lfl.dat and report.dat--------------------------%
lfl_result

if (convergence_bit==1)
 fprintf('\n\n Please wait... \n\n')    
 disp('Solution Converged !!!' );
else
 disp('Convergence is not reached !!!' );
end

elapsed_time = etime(clock,t0)
disp('See file: report.dat for details' );
