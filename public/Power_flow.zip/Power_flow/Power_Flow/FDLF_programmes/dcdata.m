%--------------------------Load the HVDC link data-------------------------%
load hvdc.dat;
load spdata.dat;

Vdor = sparse(zeros(nl,1));
Vdoi = sparse(zeros(nl,1));
Vdr = sparse(zeros(nl,1));
Vdi = sparse(zeros(nl,1));
Alpha = sparse(zeros(nl,1));
Gama = sparse(zeros(nl,1));
Phi_r = sparse(zeros(nl,1));
Phi_i = sparse(zeros(nl,1));
Pr =  sparse(zeros(nl,1));
Pi =  sparse(zeros(nl,1));
Qr =  sparse(zeros(nl,1));
Qi =  sparse(zeros(nl,1));
Id =  sparse(zeros(nl,1));


[Lno LIn] = sort(spdata(:,1));
Link_dat = spdata(LIn,:);

Re_bus  = Link_dat(:,2);  %List of Rectifier bus nos
In_bus  = Link_dat(:,3);  %List of Inverter bus nos 
link    = [Re_bus In_bus]; 

Re_Ran_data = hvdc((1:2:(2*nl-1)),:);
In_Ran_data = hvdc((2:2:2*nl),:);

for i=1:nl
 Re_data(i,:) = Re_Ran_data(Re_Ran_data(:,1)==i,:); 
 In_data(i,:) = In_Ran_data(In_Ran_data(:,1)==i,:); 
end

Br = Re_data(:,3);
Tr_max = Re_data(:,4);
Tr_min = Re_data(:,5);
Tr = Re_data(:,6);
Xcr = Re_data(:,7); 
Al_min = (pi/180)*Re_data(:,8); 
Tpr = Re_data(:,9); 
Bfr = Re_data(:,10);

Bi = In_data(:,3);
Ti_max = In_data(:,4);
Ti_min = In_data(:,5);
Ti = In_data(:,6);
Xci = In_data(:,7);
Ga_min = (pi/180)*In_data(:,8);
Tpi = In_data(:,9);
Bfi = In_data(:,10);

Vdis = Link_dat(:,4);
Idcs = Link_dat(:,5);
Pdcs = Link_dat(:,6);
Im   = Link_dat(:,7);
Rdc  = Link_dat(:,8);
Al_Lr = (pi/180)*Link_dat(:,9);
Al_Up = (pi/180)*Link_dat(:,10); 
cn = Link_dat(:,11); 
pn = Link_dat(:,12); 
Vb = Link_dat(:,13); 
Vdrn = Link_dat(:,14);

Rcr = 3/pi*Xcr.*Br;
Rci = 3/pi*Xci.*Bi;
kr = (3*sqrt(2)/pi)*Br;  
ki = (3*sqrt(2)/pi)*Bi; 

del_Tr = (Tr_max - Tr_min)./Tpr; 
del_Ti = (Ti_max - Ti_min)./Tpi; 

if(nshunt==0)
  shunt=[];
end
nshunt = nshunt + 2*nl;
shunt = [shunt;Re_bus zeros(nl,1) Bfr; In_bus zeros(nl,1) Bfi];

Idc =  sparse(zeros(nl,1));

Isp_link = Link_dat(cn==1,1);
Psp_link = Link_dat(pn==1,1);

Idc(Isp_link) = Idcs(Isp_link);
Vdr(Isp_link) = Vdrn(Isp_link);
Vdi = Vdis;



