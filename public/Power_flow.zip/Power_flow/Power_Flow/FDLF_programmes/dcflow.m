%~~~~~~~~~~~~~~~Form Real & Reactive power loads from HVDC Link side~~~~~~~~~~~~~~~~~%

if (sum(Psp_link)~=0)
 SQ_term = sqrt(Vdi(Psp_link).*Vdi(Psp_link) + 4*Pdcs(Psp_link).*Rdc(Psp_link));
 Idc(Psp_link) = (-Vdi(Psp_link) + SQ_term)./(2*Rdc(Psp_link));
 Vdr(Psp_link) = Pdcs(Psp_link)./Idc(Psp_link);
end

Vdor_Ms = ((kr.*Tr).*Vmag(Re_bus));
Al_Ms = acos((Vdr+Rcr.*Idc)./Vdor_Ms); 

%-----------------------Identifiying the Mode of operation--------------------------%

mod_con = Al_Ms >=Al_min;
mod1_link = find(mod_con==1);
mod2_link = find(mod_con==0);

%---------------------------Entering in Mode 1--------------------------------------%

mode_bit= sparse(zeros(nl,1));

if (sum(mod1_link)~=0)
 mode_bit(mod1_link)=1;  
 Gama(mod1_link) = Ga_min(mod1_link);
 Id(mod1_link) = Idc(mod1_link); 
 Vdi(mod1_link) = Vdis(mod1_link);
 
 mod1_rbus =Re_bus(mod1_link); % List of rectifier buses on mode-1
 mod1_ibus =In_bus(mod1_link); % List of Inverter buses on mode-1
 
%------------------Calculating Inverter side Parameters in mode-1--------------------%

 Ti(mod1_link) = (Vdi(mod1_link) + Rci(mod1_link).*Id(mod1_link))./((ki(mod1_link).*Vmag(mod1_ibus)).*cos(Ga_min(mod1_link)));
 Vdoi(mod1_link) = (ki(mod1_link).*Ti(mod1_link)).*Vmag(mod1_ibus);
 
%-----------Perform the following if Inverter T/f Tap limits are accounted-----------%

 if ((sum(Ti(mod1_link)>Ti_max(mod1_link))~=0)|(sum(Ti(mod1_link)<Ti_min(mod1_link))~=0))
  Ti_Uvio_All = sparse(zeros(nl,1));   
  Ti_Lvio_All = sparse(zeros(nl,1));
  mod1_sp_link = sparse(zeros(nl,1));   
  Ti_Uvio_con =find(Ti>Ti_max);
  Ti_Lvio_con =find(Ti<Ti_min);
  
  Ti_Uvio_All(Ti_Uvio_con) = Ti_Uvio_con;
  Ti_Lvio_All(Ti_Lvio_con) = Ti_Lvio_con;
  mod1_sp_link(mod1_link) = mod1_link;
  
  Ti_Uvio_int =mod1_sp_link(mod1_sp_link==Ti_Uvio_All) ;
  Ti_Lvio_int =mod1_sp_link(mod1_sp_link==Ti_Lvio_All) ;
    
  if (sum(Ti_Uvio_int)~=0)
   Ti_Uvio_link = Ti_Uvio_int(Ti_Uvio_int~=0);
  else 
   Ti_Uvio_link=[];
  end
  
  if (sum(Ti_Lvio_int)~=0)
    Ti_Lvio_link = Ti_Lvio_int(Ti_Lvio_int~=0);
  else
     Ti_Lvio_link=[];
  end
  
  if (sum(Ti_Uvio_link)~=0)
   Ti(Ti_Uvio_link) = Ti_max(Ti_Uvio_link) ;
  end
  if (sum(Ti_Lvio_link)~=0)
   Ti(Ti_Lvio_link) = Ti_min(Ti_Lvio_link) ;
  end
  Ti_vio_link = [Ti_Uvio_link;Ti_Lvio_link] ;
  Vdoi(mod1_link) = (ki(mod1_link).*Ti(mod1_link)).*Vmag(mod1_ibus);
  Vdi(Ti_vio_link) = Vdoi(Ti_vio_link).*cos(Gama(Ti_vio_link))- Rci(Ti_vio_link).*Id(Ti_vio_link);
 end%--------------- End of Inverter T/f tap limits setting--------------------------%
 
 Phi_i(mod1_link) = acos(Vdi(mod1_link)./Vdoi(mod1_link));
 Pi(mod1_link) = Vdi(mod1_link).*Id(mod1_link);
 Qi(mod1_link) = Pi(mod1_link).*tan(Phi_i(mod1_link));
 Vdr(mod1_link) = Vdi(mod1_link) + Rdc(mod1_link).*Id(mod1_link);
 Vdor(mod1_link) = (kr(mod1_link).*Tr(mod1_link)).*Vmag(mod1_rbus);
 Alpha(mod1_link) = acos((Vdr(mod1_link)+Rcr(mod1_link).*Id(mod1_link))./Vdor(mod1_link));
 
 
%------------Perform the following if Alpha-limits are Accounted-----------------------% 
 
 Al_Uvio_link = find(Alpha(mod1_link)>Al_Up(mod1_link));
 Al_Lvio_link = find(Alpha(mod1_link)<Al_Lr(mod1_link));
 Re_Uvio_bus = Re_bus(Al_Uvio_link);
 Re_Lvio_bus = Re_bus(Al_Lvio_link); 
 
 if(sum(Al_Uvio_link)~=0)
  while (Alpha(Al_Uvio_link) > Al_Up(Al_Uvio_link))
   Tr(Al_Uvio_link) = Tr(Al_Uvio_link) - del_Tr(Al_Uvio_link);
   Vdor(Al_Uvio_link) = (kr(Al_Uvio_link).*Tr(Al_Uvio_link)).*Vmag(Re_Uvio_bus);
   Alpha(Al_Uvio_link) = acos((Vdr(Al_Uvio_link)+Rcr(Al_Uvio_link).*Id(Al_Uvio_link))./Vdor(Al_Uvio_link));
  end
 end
 
 if(sum(Al_Lvio_link)~=0)
  while (Alpha(Al_Lvio_link)< Al_Lr(Al_Lvio_link))
   Tr(Al_Lvio_link) = Tr(Al_Lvio_link) + del_Tr(Al_Lvio_link);
   Vdor(Al_Lvio_link) = (kr(Al_Lvio_link).*Tr(Al_Lvio_link)).*Vmag(Re_Lvio_bus);
   Alpha(Al_Lvio_link) = acos((Vdr(Al_Lvio_link)+Rcr(Al_Lvio_link).*Id(Al_Lvio_link))./Vdor(Al_Lvio_link));
  end
 end %--------Alpha-Limits parts ends here--------------------------------------------%
 
 %-----------Perform the following if Rectifier T/f Tap limits are accounted----------%

 if ((sum(Tr(mod1_link)>Tr_max(mod1_link))~=0)|(sum(Tr(mod1_link)<Tr_min(mod1_link))~=0))
  Tr_Uvio_All = sparse(zeros(nl,1));   
  Tr_Lvio_All = sparse(zeros(nl,1));
  mod1_sp_link = sparse(zeros(nl,1));   
  
  Tr_Uvio_con =find(Tr>Tr_max);
  Tr_Lvio_con =find(Tr<Tr_min);
  
  Tr_Uvio_All(Tr_Uvio_con) = Tr_Uvio_con;
  Tr_Lvio_All(Tr_Lvio_con) = Tr_Lvio_con;
  mod1_sp_link(mod1_link) = mod1_link;
  
  Tr_Uvio_int =mod1_sp_link(mod1_sp_link==Tr_Uvio_All) ;
  Tr_Lvio_int =mod1_sp_link(mod1_sp_link==Tr_Lvio_All) ;
  
  if (sum(Tr_Uvio_int)~=0)
   Tr_Uvio_link = Tr_Uvio_int(Tr_Uvio_int~=0);
  else
   Tr_Uvio_link=[];
  end   
  if (sum(Tr_Lvio_int)~=0)
   Tr_Lvio_link = Tr_Lvio_int(Tr_Lvio_int~=0);
  else
   Tr_Lvio_link=[];
  end
  
  if (sum(Tr_Uvio_link)~=0)
   Tr(Tr_Uvio_link) = Tr_max(Tr_Uvio_link) ;
  end
  
  if (sum(Tr_Lvio_link)~=0)
   Tr(Tr_Lvio_link) = Tr_min(Tr_Lvio_link) ;
  end
  Tr_vio_link = [Tr_Uvio_link;Tr_Lvio_link];
  Vdor(mod1_link) = (kr(mod1_link).*Tr(mod1_link)).*Vmag(mod1_rbus);
  Alpha(Tr_vio_link) = acos((Vdr(Tr_vio_link)+Rcr(Tr_vio_link).*Id(Tr_vio_link))./Vdor(Tr_vio_link));
 end %--------------------------Alpha-Limits parts ends here-------------------------%
 Phi_r(mod1_link) = acos(Vdr(mod1_link)./Vdor(mod1_link));
 Pr(mod1_link) = Vdr(mod1_link).*Id(mod1_link);
 Qr(mod1_link) = Pr(mod1_link).*tan(Phi_r(mod1_link));
end
  
%------------------------------- Entering in Mode 2----------------------------------%

if(sum(mod2_link)~=0)
 mode_bit(mod2_link)=2;
 Alpha(mod2_link) = Al_min(mod2_link);
 
 mod2_sp_link = sparse(zeros(nl,1));
 Psp_sp_link = sparse(zeros(nl,1)); 
 mod2_sp_link(mod2_link)  = mod2_link;
 Psp_sp_link(Psp_link) = Psp_link;
 
 mod2_Psp_con = mod2_sp_link(mod2_sp_link==Psp_sp_link);
 
 if (sum(mod2_Psp_con)~=0)
   mod2_Psp_link = mod2_Psp_con(mod2_Psp_con~=0);  % list of mode2 Pspecified link nos
 else
   mod2_Psp_link=[];
 end
 
 mod2_Isp_con = mod2_sp_link(mod2_sp_link~=Psp_sp_link);% list of mode2 Ispecified link nos
 if (sum(mod2_Isp_con)~=0)
   mod2_Isp_link = mod2_Isp_con(mod2_Isp_con~=0);  % list of mode2 Pspecified link nos
 else
   mod2_Isp_link=[];
 end
 
 mod2_rbus =Re_bus(mod2_link); % List of rectifier buses on mode-2
 mod2_ibus =In_bus(mod2_link); % List of Inverter buses on mode-2
 
 Vdor(mod2_link) = (kr(mod2_link).*Tr(mod2_link)).*Vmag(mod2_rbus);
 
 if (sum(mod2_Isp_link)~=0)
  Id(mod2_Isp_link) = Idc(mod2_Isp_link)-Im(mod2_Isp_link);  
  Vdr(mod2_Isp_link) = Vdor(mod2_Isp_link).*cos(Alpha(mod2_Isp_link))- Rcr(mod2_Isp_link).*Id(mod2_Isp_link) ;
  Pr(mod2_Isp_link) = Vdr(mod2_Isp_link).*Id(mod2_Isp_link);
 end
 
 if (sum(mod2_Psp_link)~=0)
   Pr(mod2_Psp_link) = Pdcs(mod2_Psp_link);  
   Vdor_cp = Vdor(mod2_Psp_link).*cos(Alpha(mod2_Psp_link));
   Id(mod2_Psp_link) =  (Vdor_cp - sqrt(Vdor_cp.*Vdor_cp - 4*Pr(mod2_Psp_link).*Rcr(mod2_Psp_link)))./(2*Rcr(mod2_Psp_link));
   Vdr(mod2_Psp_link) =  Pr(mod2_Psp_link)./Id(mod2_Psp_link);
 end
  
 Phi_r(mod2_link) = acos(Vdr(mod2_link)./Vdor(mod2_link));
 Qr(mod2_link) = Pr(mod2_link).*tan(Phi_r(mod2_link));
  
 Vdi(mod2_link) = Vdr(mod2_link)- Rdc(mod2_link).*Id(mod2_link);
 Vdoi(mod2_link) = (ki(mod2_link).*Ti(mod2_link)).*Vmag(mod2_ibus);
 Gama(mod2_link) = acos((Vdi(mod2_link)+ Rci(mod2_link).*Id(mod2_link))./Vdoi(mod2_link));
  
%------------Perform the following if Gama-limits are Accounted----------------------% 
 
 Ga_vio_link = find(Gama(mod2_link) < Ga_min(mod2_link));
 Ga_vio_bus = In_bus(Ga_vio_link);
 
 if(sum(Ga_vio_link)~=0)
  while (Gama(mod2_link) < Ga_min(mod2_link))  
   Ti(Ga_vio_link) = Ti(Ga_vio_link) - del_Ti(Ga_vio_link);
   Vdoi(Ga_vio_link) = (ki(Ga_vio_link).*Ti(Ga_vio_link)).*Vmag(Ga_vio_bus);
   Gama(Ga_vio_link) = acos((Vdi(Ga_vio_link)+ Rci(Ga_vio_link).*Id(Ga_vio_link))./Vdoi(Ga_vio_link));
  end
 end   %--------------------------Gama-Limit parts ends here-------------------------%
 
 
%-----------Perform the following if Inverter T/f Tap limits are accounted-----------%
 
 if ((sum(Ti(mod2_link)>Ti_max(mod2_link))~=0)|(sum(Ti(mod2_link)<Ti_min(mod2_link))~=0))
  Ti_Uvio_All = sparse(zeros(nl,1));   
  Ti_Lvio_All = sparse(zeros(nl,1));
  mod2_sp_link = sparse(zeros(nl,1));   
  
  Ti_Uvio_con =find(Ti>Ti_max);
  Ti_Lvio_con =find(Ti<Ti_min);
  
  Ti_Uvio_All(Ti_Uvio_con) = Ti_Uvio_con;
  Ti_Lvio_All(Ti_Lvio_con) = Ti_Lvio_con;
  mod2_sp_link(mod2_link) = mod2_link;
  
  Ti_Uvio_int =mod2_sp_link(mod2_sp_link==Ti_Uvio_All) ;
  Ti_Lvio_int =mod2_sp_link(mod2_sp_link==Ti_Lvio_All) ;
  
  if (sum(Ti_Uvio_int)~=0)
   Ti_Uvio_link = Ti_Uvio_int(Ti_Uvio_int~=0);
  else 
   Ti_Uvio_link=[];
  end
  
  if (sum(Ti_Lvio_int)~=0)
    Ti_Lvio_link = Ti_Lvio_int(Ti_Lvio_int~=0);
  else
     Ti_Lvio_link=[];
  end
  
  if (sum(Ti_Uvio_link)~=0)
   Ti(Ti_Uvio_link) = Ti_max(Ti_Uvio_link) ;
  end
  if (sum(Ti_Lvio_link)~=0)
   Ti(Ti_Lvio_link) = Ti_min(Ti_Lvio_link) ;
  end
  Ti_vio_link = [Ti_Uvio_link;Ti_Lvio_link] ;
  Vdoi(mod2_link) = (ki(mod2_link).*Ti(mod2_link)).*Vmag(mod2_ibus);
  Gama(Ti_vio_link) = acos((Vdi(Ti_vio_link)+ Rci(Ti_vio_link).*Id(Ti_vio_link))./Vdoi(Ti_vio_link));
 end%---------- End of Inverter T/f tap limits setting -----------------------------%
 
 Vdi_vio_link = find(Vdi>Vdoi);
 if (sum(Vdi_vio_link)~=0)
   Vdoi(Vdi_vio_link) = Vdi(Vdi_vio_link);
 end
 Phi_i(mod2_link) = acos(Vdi(mod2_link)./Vdoi(mod2_link)) ;
 Pi(mod2_link) = Vdi(mod2_link).*Id(mod2_link);
 Qi(mod2_link) = Pi(mod2_link).*tan(Phi_i(mod2_link));
end

 
