%---------------ybus--------------------------
Y=sparse(zeros(nb,nb));
Yd=sparse(zeros(nb,nb));

for i=1:nline
incr=1/(nt(i,3)+j*nt(i,4));
Y((nt(i,1)),(nt(i,2)))=Y((nt(i,1)),(nt(i,2)))-incr;
Y((nt(i,2)),(nt(i,1)))=Y((nt(i,2)),(nt(i,1)))-incr;
Y((nt(i,1)),(nt(i,1)))=Y((nt(i,1)),(nt(i,1)))+incr+j*nt(i,5)/2;
Y((nt(i,2)),(nt(i,2)))=Y((nt(i,2)),(nt(i,2)))+incr+j*nt(i,5)/2;
end

for i=nline+1:(ntrans+nline)
incr=1/(nt(i,3)+j*nt(i,4));  
incr1=incr/nt(i,5);
incr2=(1-nt(i,5))*incr/(nt(i,5)*nt(i,5));
incr3=(nt(i,5)-1)*incr/nt(i,5);
Y((nt(i,1)),(nt(i,2)))=Y((nt(i,1)),(nt(i,2)))-incr1;
Y((nt(i,2)),(nt(i,1)))=Y((nt(i,2)),(nt(i,1)))-incr1;
Y((nt(i,1)),(nt(i,1)))=Y((nt(i,1)),(nt(i,1)))+incr1+incr2;
Y((nt(i,2)),(nt(i,2)))=Y((nt(i,2)),(nt(i,2)))+incr1+incr3; 
end

for i=1:nshunt
incr=shunt(i,2)+j*shunt(i,3);   
Y((shunt(i,1)),(shunt(i,1)))=Y((shunt(i,1)),(shunt(i,1)))+incr;
end

%------Preparation of Y matrix to obtain Bd matrix----
for i=1:(nline + ntrans) 
   incr=1/(j*nt(i,4));
   Yd((nt(i,1)),(nt(i,2)))=Yd((nt(i,1)),(nt(i,2)))-incr;
   Yd((nt(i,2)),(nt(i,1)))=Yd((nt(i,2)),(nt(i,1)))-incr;
   Yd((nt(i,1)),(nt(i,1)))=Yd((nt(i,1)),(nt(i,1)))+incr;
   Yd((nt(i,2)),(nt(i,2)))=Yd((nt(i,2)),(nt(i,2)))+incr;
end
  Bd = -imag(Yd);
  Bd(sl,:) = [];
  Bd(:,sl) = [];
%-------------------------------------------------------------------------%
%------------------------------formation of Bdd matrix--------------------%      
  Bdd_bus = -imag(Y);
%-------------------------------------------------------------------------%


