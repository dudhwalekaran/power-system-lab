%--------------------Preparation of Load flow Results------------------------------%
Bno=[1:nb]';
PG=sparse(zeros(nb,1));
QG=sparse(zeros(nb,1));

Pc=real(S);
Qc=imag(S);
if(Load_bit~=0 | Freq_bit~=0)
  QG_pv = Qc(pv_data(:,1))+ QL(pv_data(:,1))+ Qdc(pv_data(:,1));
else
 PL = sparse(zeros(nb,1));
 QL = sparse(zeros(nb,1));
 PL([sl;pq_data(:,1)])=[sl_load(1,2);pq_data(:,2)];
 QL([sl;pq_data(:,1)])=[sl_load(1,3);pq_data(:,3)];
 QG_pv = Qc(pv_data(:,1))+ Qload(pv_data(:,1));
end

PG([sl;pv_data(:,1)])=[Pc(sl); pv_data(:,3)];
QG([sl;pv_data(:,1)])=[Qc(sl); QG_pv];


if (nl~=0)
 com_ani = acos(2*Vdi./Vdoi-cos(Gama))-Gama;
 com_anr = acos(2*Vdr./Vdor-cos(Alpha))-Alpha;
end

fid=fopen('report.dat', 'a');
if (Q_bit~=0)
   fprintf(fid,' Q-limits at PV-buses accounted\n ' );
   fprintf(fid,'------------------------------------------------------------\n');

end
if (Load_bit~=0)
   fprintf(fid,' Voltage-dependent load models are accounted\n  ' ); 
   fprintf(fid,'------------------------------------------------------------\n');
end

if(Freq_bit~=0)
 F = 50*(1 + delF);
 fprintf(fid,' Frequency-dependent load models are accounted\n  ' ); 
 fprintf(fid,'------------------------------------------------------------\n');
 fprintf(fid,' System Nominal Frequency in Hz = %i \n',50); 
 fprintf(fid,' System New Frequency in Hz = %3.4f\n',F); 
 fprintf(fid,'-----------------------------------\n');
end
fprintf(fid,' Loadflow results:\n'); 
fprintf(fid,'---------------------------------------------------------------------------------------\n');
fprintf(fid,'\nBus No     VbO          thetaO           PGO             QGO         PLO         QLO \n');
fprintf(fid,'---------------------------------------------------------------------------------------\n');
fprintf(fid,'%3i \t %12.6f \t%12.6f\t%12.6f\t%12.6f\t%9.6f\t%9.6f \n',[Bno  full(Vmag) full(Vang*180/pi) full(PG)  full(QG)  full(PL) full(QL)]');
fprintf(fid,'---------------------------------------------------------------------------------------\n');
fprintf(fid,'Line flows:\n');
fprintf(fid,'----------------------------------------------------------------------------------\n');
fprintf(fid,'                       Line flows                                Line flows \n');
fprintf(fid,'                   _____________________                   _______________________\n');
fprintf(fid,' From   To         P-flow         Q-flow    From   To      P-flow           Q-flow\n');
fprintf(fid,'----------------------------------------------------------------------------------\n');
fprintf(fid,'%3i \t %3i\t %12.4f\t %12.4f\t %3i\t %4i\t %12.4f\t %12.4f\n',[nt(:,1) nt(:,2) full(real(Spq)) full(imag(Spq)) nt(:,2) nt(:,1) full(real(Sqp)) full(imag(Sqp))]');
fprintf(fid,'----------------------------------------------------------------------------------\n');
fprintf(fid,'Total real power losses in the system = %9.6f\n',full(real(S_line_loss)));
fprintf(fid,'Total reactive power losses in the system = %9.6f\n',full(imag(S_line_loss)));
fprintf(fid,'----------------------------------------------------------------------------------\n');

%-------------------------------Hvdc Results-------------------------%
if (nl~=0)
 for i=1:nl
  fprintf(fid,' Results of The D.C.Link:%3i\t\n',i); 
  fprintf(fid,'----------------------------------------------------------\n');
  fprintf(fid,'\nParameter                     Rectifier      Inverter \n');
  fprintf(fid,'----------------------------------------------------------\n');
  fprintf(fid,'Bus no %30i\t%13i\n',[Re_bus(i) In_bus(i)]);
  fprintf(fid,'D.C.Voltage(pu) %27.6f\t%12.6f\n',[Vdr(i) Vdi(i)]);
  fprintf(fid,'Transformer tap Position(pu) %14.6f\t%12.6f\n',[Tr(i) Ti(i)]);
  fprintf(fid,'Control Angles(Deg) %23.6f\t%12.6f\n',[Alpha(i)*180/pi Gama(i)*180/pi]);
  fprintf(fid,'Commutation overlap Angles(Deg) %11.6f\t%12.6f\n',[com_anr(i)*180/pi com_ani(i)*180/pi]);
  fprintf(fid,'Real Power flow(pu) %23.6f\t%12.6f\n',[Pr(i) Pi(i)]);
  fprintf(fid,'Reactive power consumption(pu) %12.6f\t%12.6f\n',[Qr(i) Qi(i)]);
  fprintf(fid,'Power factor %30.6f\t%12.6f\n',[cos(Phi_r(i)) cos(Phi_i(i)) ]);
  fprintf(fid,'Current in the D.C.Link(pu) %15.6f\t\n',[Id(i)]);
  fprintf(fid,'----------------------------------------------------------\n');
  fprintf(fid,'Voltage Base in KV = %5.2f\t\n',Vb(i));
 fprintf(fid,'----------------------------------------------------------\n');
 end
 end
%---------------------------------------------------------------------------------%

if (convergence_bit==1)
 fid1=fopen('lfl.dat','w');
 fprintf(fid1,'%3i \t %12.6f \t%12.6f\t%12.6f\t%12.6f\t%9.6f\t%9.6f \n',[Bno  full(Vmag) full(Vang*180/pi) full(PG)  full(QG)  full(PL) full(QL)]');
 fclose(fid1);
 if (nl~=0) 
  fid2=fopen('hvdc_res.dat','w');
  fprintf(fid2,'%3i \t %9.6f \t%12.6f\t%12.6f\t%9.6f\t%9.6f\t%9.6f\t%5.2f\t \n',[[Re_bus;In_bus] [full(Vdr); full(Vdi)] [full(Tr);full(Ti)] [full(Pr);full(Pi)] [full(Qr);full(Qi)]  [full(Alpha*180/pi); full(Gama*180/pi)]  [cos(full(Phi_r)); cos(full(Phi_i))] [Vb(1:nl,1);Vb(1:nl,1)]]');
  fclose(fid2);
 end
else
 fprintf(fid,'Convergence is not reached !!!' );
end
fclose(fid);
