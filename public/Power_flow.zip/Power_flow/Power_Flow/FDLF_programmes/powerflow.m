%-----------------------------Calculating Power flows--------------------------------%
S_sh = sparse(zeros(nshunt,1));
for i=1:nline
   Ipq(i)=(Vbus(nt(i,1)) - Vbus(nt(i,2)))/(nt(i,3)+j*nt(i,4)) + j*Vbus(nt(i,1))*(nt(i,5)/2);
   Iqp(i)=(Vbus(nt(i,2)) - Vbus(nt(i,1)))/(nt(i,3)+j*nt(i,4)) + j*Vbus(nt(i,2))*(nt(i,5)/2);
end
for i=nline+1:nline+ntrans
   incr=1/(nt(i,3)+j*nt(i,4));
   incr1=incr/nt(i,5);
   incr2=(1-nt(i,5))*incr/(nt(i,5)*nt(i,5));
   incr3=(nt(i,5)-1)*incr/nt(i,5);
   Ipq(i)=(Vbus(nt(i,1)) - Vbus(nt(i,2)))*incr1 + Vbus(nt(i,1))*incr2 ;
   Iqp(i)=(Vbus(nt(i,2)) - Vbus(nt(i,1)))*incr1 + Vbus(nt(i,2))*incr3;  
end
if (nshunt~=0)
 for i=1:nshunt
  incr=shunt(i,2)+j*shunt(i,3);   
  Ish(i)= Vbus(shunt(i,1))*incr;
end
 S_sh = Vbus(shunt(:,1)).*Ish';
end
Spq = Vbus(nt(:,1)).* Ipq';
Sqp = Vbus(nt(:,2)).* Iqp';

if (nl~=0)
 S_line_loss = sum(Spq+Sqp) + sum(S_sh) + sum(Id.^2.*Rdc);
else 
 S_line_loss = sum(Spq+Sqp) + sum(S_sh);
end


%--------------------------------------------------------------------------------------%          