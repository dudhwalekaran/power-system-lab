



% A MATLAB program for the small signal analysis of a multimachine power
% system. 2.2 Machine model is used with a STATIC,DC1A,AC4A EXCITERS;HYDRO,RHT STEAM TURBINES;SLIP PSS ;



%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
clear all;

load busno.dat;

load nt.dat;

load gen.dat;

load ld.dat;

	if (busno(9)~=0)
load shunt.dat;
end

nb=busno(3);
nline=busno(4);
ntrans=busno(5);
ngen=size(gen,1);
nshunt=busno(9);
nload=size(ld,1);
wB=busno(11)*2*pi


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Calculate the initial conditions
initcond
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

%~~~~~~~~~~~~~~~~~~~~~~~
% Formation of YDQ and YBUS matrix
yform
%~~~~~~~~~~~~~~~~~~~~~~~

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Formation of the PG and  PL matrices
pmat
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Selection of type of exciters: Single time constant static, DC1A, AC4A
exciter_setting
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

% Selection of type of turbines: Hydro and Reheat steam turbine
primemover_setting
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Formation of Generator matrices:AG, BG, CG and DG (YG)
genmat1
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~

YDQdash=PG*YG*PG';
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~

% Formation of YL matrices for Static loads 
statld
YDQdash=YDQdash+ PL*YL*PL';
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% YDQ  matrix is formed in yform.m
YDQdash=YDQdash+YDQ;
YDQdi=YDQdash\eye(size(YDQdash));

% Anp -state matrix without PSS.
%------------------------------------
Anp = sparse(AG+BG*PG'*YDQdi*PG*CG);
CGnp=CG;
%Updation of AG, BG, CG matrices to include slip signal-based PSS
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
AT = Anp;

if (npss~=0)
   slip_pss_settings
end
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if (npss1~=0)
   delPw_pss_settings
end
if (npss2~=0)
   power_pss_settings
end

if ((npss+npss1+npss2)~=0)
   AT=sparse(AG+BG*PG'*YDQdi*PG*CG);
   Ap=AT;
end
%Unreduced A matrix for the system

% Formation of Reduced A matrix
AT(1,:)=[];
AT(:,1)=[];
aa=sparse(zeros(size(AT)*[1 0]',size(AT)*[0 1]'));
aa(16:16:16*ngen-1,1)=ones(ngen-1,1);
AT=(AT-wB*aa);

% The Order of occurrences of states X for a genarator is decided by its
% row position in gen.dat

