
%----Power signal based PSS----
load power_pss.dat
%Modfy the power_pss to suit the enabled PSS
PSS_dash=~(PSS);
PSS_sm=PSS_dash(gen(:,1));
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
SL_power_pss_dash=~(SL_power_pss);
SL_power_pss_dash=SL_power_pss_dash(gen(:,1));
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PS3d=SL_power_pss_dash.*PSS_sm;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
npss2=sum(PS3d);
if (npss2~=0&npss2~=size(power_pss,1))
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
power_pss_temp=power_pss;
clear power_pss;
k=1;
for i=1:ngen
   if(PS3d(i)~=0)
      x(k)=gen(i,1);
      k=k+1;
   end
end
m=1;
for i=1:size(power_pss_temp,1)
   for np=1:npss2 
      if(power_pss_temp(i)==x(np))
         power_pss(m,:)=power_pss_temp(i,:);
         m=m+1;
      end
   end
end
%-------------------------------------------------------------------------------------
clear power_pss_temp;
end
[mm order_power_pss]=sort([setxor(1:nb,power_pss(:,1));power_pss(:,1)]);
Tm0_power=TmA0(power_pss(:,1)');
Tw_power=power_pss(:,2)';
Td1_power=power_pss(:,3)';
Kpower_pss=power_pss(:,4)';
VS_power_max=power_pss(:,5)';
VS_power_min=power_pss(:,6)';



