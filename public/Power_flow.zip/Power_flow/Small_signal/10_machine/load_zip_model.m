%-------------------Load Modelling------------------

%Real power component: (p1+p2+p3=1)
p1=0;
p2=0;
p3=1;
%Reactive power component: (r1+r2+r3 =1)
r1=0;
r2=0;
r3=1;

% constant Power type
kcpr=r1*QL0;
kcp=p1*PL0;
% constant current type
kccr=r2*QL0./VL0;
kcc= p2*PL0./VL0;
% constant impedance type
kcir=r3*QL0./(VL0.^2);
kci=p3*PL0./(VL0.^2);

TL=0.01;
% Selector for  loads%

[mm order_load]=sort([setxor(1:nb,ld(:,1));ld(:,1)]);
