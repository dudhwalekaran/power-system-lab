
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~               
%            Formation of YL (STATIC LOADS)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
mp=0;
mi=1;
mz=2;
np=0;
ni=1;
nz=2;

mk=mp*p1+mi*p2+mz*p3;
nk=np*r1+ni*r2+nz*r3;

% VL0 and theL0 are obtained in initcond.m
VDl0=VL0.*sin(theL0);
VQl0=VL0.*cos(theL0);


BDQ=(QL0.*((nk-2).*VQl0.*VQl0./VL0./VL0+1)./VL0./VL0)-(PL0.*((mk-2).*VQl0.*VDl0./VL0./VL0)./VL0./VL0);

GDD=(PL0.*((mk-2).*VDl0.*VDl0./VL0./VL0+1)./VL0./VL0)-(QL0.*((nk-2).*VQl0.*VDl0./VL0./VL0)./VL0./VL0);

GQQ=(PL0.*((mk-2).*VQl0.*VQl0./VL0./VL0+1)./VL0./VL0)+(QL0.*((nk-2).*VQl0.*VDl0./VL0./VL0)./VL0./VL0);

BQD=(QL0.*((nk-2).*VDl0.*VDl0./VL0./VL0+1)./VL0./VL0)+(PL0.*((mk-2).*VQl0.*VDl0./VL0./VL0)./VL0./VL0);



YLmod=sparse([diag(-BDQ) diag(GDD);diag(GQQ) diag(BQD)]);


YL=YLmod(mmm,mmm);

clear YLmod;

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

