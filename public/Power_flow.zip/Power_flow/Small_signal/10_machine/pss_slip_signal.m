%------Slip signal based PSS----
load slip_pss.dat
%Modfy the slip_pss to suit the enabled PSS
PSS_dash=~(PSS);
PSS_sm=PSS_dash(gen(:,1));
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
SL_slip_pss_dash=~(SL_slip_pss);
SL_slip_pss_dash=SL_slip_pss_dash(gen(:,1));
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PS1d=SL_slip_pss_dash.*PSS_sm;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
npss=sum(PS1d);
if (npss~=0&npss~=size(slip_pss,1))
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
slip_pss_temp=slip_pss;
clear slip_pss;
k=1;
for i=1:ngen
   if(PS1d(i)~=0)
      x(k)=gen(i,1);
      k=k+1;
   end
end
m=1;
for i=1:size(slip_pss_temp,1)
   for np=1:npss 
      if(slip_pss_temp(i)==x(np))
         slip_pss(m,:)=slip_pss_temp(i,:);
         m=m+1;
      end
   end
end
%---------------------------------------------------------
clear slip_pss_temp;
end


[mm order_slip_pss]=sort([setxor(1:nb,slip_pss(:,1));slip_pss(:,1)]);
Kslip_pss=slip_pss(:,2)';
Td1_slip=slip_pss(:,3)';
Tw_slip=slip_pss(:,4)';
T1_slip=slip_pss(:,5)';
T2_slip=slip_pss(:,6)';
VS_slip_max=slip_pss(:,7)';
VS_slip_min=slip_pss(:,8)';
a0_slip=slip_pss(:,9)';
a1_slip=slip_pss(:,10)';
TRF_slip=slip_pss(:,11)';
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%Globalization of all parameters..
Kslip_pss_g=sparse(zeros(1,nb));
Kslip_pss_g(slip_pss(:,1))=Kslip_pss;
Td1_slip_g=sparse(zeros(1,nb));
Td1_slip_g(slip_pss(:,1))=Td1_slip;
Tw_slip_g=sparse(zeros(1,nb));
Tw_slip_g(slip_pss(:,1))=Tw_slip;
T1_slip_g=sparse(zeros(1,nb));
T1_slip_g(slip_pss(:,1))=T1_slip;
T2_slip_g=sparse(zeros(1,nb));
T2_slip_g(slip_pss(:,1))=T2_slip;
a0_slip_g=sparse(zeros(1,nb));
a0_slip_g(slip_pss(:,1))=a0_slip;
a1_slip_g=sparse(zeros(1,nb));
a1_slip_g(slip_pss(:,1))=a1_slip;
TRF_slip_g=sparse(zeros(1,nb));
TRF_slip_g(slip_pss(:,1))=TRF_slip;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
xpss_nt=[];
xpss_t=[];
gnt=1;
gt=1;
for i=1:size(slip_pss,1)
   if(slip_pss(i,11)==1)
      xpss_nt(gnt)=slip_pss(i,1);
      gnt=gnt+1;
   else
      xpss_t(gt)=slip_pss(i,1);
      gt=gt+1;
   end
end

%-To enable or disable measurement time delay--set it '0' for Enable and '1' to disable---
Tmd_slip_nt = 1;  %--- Without Torsional Filter 
Tmd_slip_t = 0;   %--- With Torsional Filter 

Tmd_slip = zeros(1,nb);
Tmd_slip(xpss_nt) = Tmd_slip_nt;
Tmd_slip(xpss_t) = Tmd_slip_t;
Tmd_slip = Tmd_slip(slip_pss(:,1));
   





