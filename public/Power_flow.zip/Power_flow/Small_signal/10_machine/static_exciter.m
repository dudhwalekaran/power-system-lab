
%----------------------Static - type exciters--------------------------

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
load exc_static.dat
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[mm order_static]=sort([setxor(1:nb,exc_static(:,1));exc_static(:,1)]);

kA_static=exc_static(:,2)';
TA_static=exc_static(:,3)';

Efd_min_static=exc_static(:,4)';
Efd_max_static=exc_static(:,5)';

Efd0_static=EFD0(exc_static(:,1));

Vref_static=Efd0_static./kA_static + lfl(exc_static(:,1),2)';