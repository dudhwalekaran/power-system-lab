%~~~~~~~~~~~~~Form Jacobian and solve for bus voltages and angles~~~~~~~~~~%
Vmag=sparse(ones(nb,1));
Vang=sparse(zeros(nb,1));
Vmag(pv_data(:,1))=pv_data(:,2);  %Replaces the voltages of P-V buses in Vmag 
Vmag(sl) = Vsl;
Vang(sl) = 0;
kp = 0;
kq = 0;
fid=fopen('report.dat', 'w');
%------------------Iteration begins from here onwards---------------------%
for k=1:200
   Vbus=Vmag.*(cos(Vang)+ j*sin(Vang));
%----------------------------------bus powers calculations----------------%
   S=Vbus.*(conj(Y*Vbus));
   Pc=real(S);
   Qc=imag(S);
%---------------------finding non slack and non pv buses------------------%
   pv_num=pv_data(:,1);
   pv_sl_num=[pv_num;sl];
   num_no_sl_pv =[1:nb]'; 
   num_no_sl_pv(pv_sl_num,:)=[];
 %------------------------bus power mis matches -------------------------%
   delP=Psp-Pc;
   delP(sl,:)=[];
   delQ=Qsp-Qc;
   delQ(pv_sl_num,:)=[];
   if (max(abs(delP))<= tole)
     if (max(abs(delQ))<= tole)
      fprintf(fid,'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n');
      fprintf(fid,'Converged Real power mismatch iteration No = %i, Max.mismatch = %10.8f\n',kp, full(max(abs(delP))));
      fprintf(fid,'Converged Reactive power mismatch iteration No = %i, Max. mismatch = %10.8f\n',kq, full(max(abs(delQ))));
      convergence_bit=1;
      S(sl)= S(sl)+(sl_load(1,2)+j*sl_load(1,3));
      fprintf(fid,'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n');
      break;
     end
   else
     kp=kp+1;
     if(k~=1)
      del_Pm=sparse(zeros(nb,1)); 
      del_Pm(sort([pv_num;num_no_sl_pv]))=delP;
      Bno=[1:nb]';
      vio_busP = Bno(abs(del_Pm)==max(abs(del_Pm)));
      fprintf(fid,'Iter. No = %i Max. Real power mismatch at bus = %i, Max. mismatch = %10.8f\n',(kp-1),full(vio_busP),full(max(abs(del_Pm))));
     end
  
    %---------------------Updation of bus angles at each bus----------------% 
     del_Vang = Bd\(delP./Vmag(num_nosl));
   
     Vang(num_nosl)=Vang(num_nosl)+ del_Vang;
  end
  %--------------------Updation of bus voltages at each bus-----------------% 
  Vbus = Vmag.*(cos(Vang)+ j*sin(Vang));
  S=Vbus.*(conj(Y*Vbus));
  Qc = imag(S);
  delQ=Qsp-Qc;
  delQ(pv_sl_num,:)=[];
     
  %-----------Perform the following if Q-limit is accounted--------------%
  pv_num_Uvio=sparse(zeros(nb,1));
  pv_num_Lvio=sparse(zeros(nb,1));
     
  if (Q_bit~=0 & max(abs(delQ))<=0.1)
 
    Qc(pvpq_buses) = Qc(pvpq_buses) + Qload(pvpq_buses); 
       
  %----------------------checking Qlimit voilation-----------------------%
    if (sum(Qc(pv_num)>QUlim(pv_num))>=1)
     pv_num_Uvio(pv_num)=[Qc(pv_num)>QUlim(pv_num)];
        
     pv_num=[pv_num(Qc(pv_num)<QUlim(pv_num))];
     pv_sl_num=[pv_num;sl];
     num_no_sl_pv = [1:nb]';
     num_no_sl_pv(pv_sl_num,:)=[];
    end
        
    if (sum(Qc(pv_num)<QLlim(pv_num))>=1)
     pv_num_Lvio(pv_num) =[Qc(pv_num)<QLlim(pv_num)];
          
     pv_num=[pv_num(Qc(pv_num)>QLlim(pv_num))];
     pv_sl_num=[pv_num;sl];
     num_no_sl_pv = [1:nb]';
     num_no_sl_pv(pv_sl_num,:)=[];
    end
        
    Qsp = sparse(zeros(nb,1));
    Qsp(pq_data(:,1)) = -pq_data(:,3);
    Qsp = Qsp + (pv_num_Uvio.*QUlim)+ (pv_num_Lvio.*QLlim);
         
    Vmag(pv_num)=pv_Vmag(pv_num);  %Again Replace the voltages of P-V buses in Vmag 
       
   %------------------------Re-calculation of bus powers --------------------%
    Vbus=Vmag.*(cos(Vang)+ j*sin(Vang));
    S=Vbus.*(conj(Y*Vbus));
    Qc = imag(S);
  end       %----------------Q-limit part ends here----------------------%
      
  delP=Psp-real(S);
  delP(sl,:)=[];
  delQ=Qsp-Qc;
  delQ(pv_sl_num,:)=[];
   
  if (max(abs(delQ))<= tole)
   if (max(abs(delP))<= tole)
    fprintf(fid,'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n');
    fprintf(fid,'Converged Real power mismatch iteration No = %i, Max.mismatch = %10.8f\n',kp, full(max(abs(delP))));
    fprintf(fid,'Converged Reactive power mismatch iteration No = %i, Max. mismatch = %10.8f\n',kq, full(max(abs(delQ))));
    convergence_bit=1;
    S(sl)= S(sl)+(sl_load(1,2)+j*sl_load(1,3));
    fprintf(fid,'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n');
    break;
   end
  else
   kq = kq+1; 
   if(k~=1)
    del_Qm=sparse(zeros(nb,1));
    del_Qm(num_no_sl_pv)=delQ;
    Bno=[1:nb]';
    vio_busQ=Bno(abs(del_Qm)==max(abs(del_Qm)));
    fprintf(fid,'Iter. No = %i Max. Reactive power mismatch at bus = %i, Max. mismatch = %10.8f\n',(kq-1),full(vio_busQ),full(max(abs(del_Qm))));
   end 
        
   Bdd = Bdd_bus;
   Bdd(:,pv_sl_num)=[];
   Bdd(pv_sl_num,:)=[];
   
   del_Vmag = Bdd\(delQ./Vmag(num_no_sl_pv));
   Vmag(num_no_sl_pv)=Vmag(num_no_sl_pv) + del_Vmag;
     
   if (sum(pv_num_Uvio + pv_num_Lvio)~=0)
    pv_Vmag(pv_data(:,1)) = Vmag(pv_data(:,1));
   end
  end
end

fclose(fid);



