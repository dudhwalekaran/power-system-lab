

%----------------------Alternator supplied Controlled Rectifier: AC4A type-

load exc_AC4A.dat

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
[mm order_AC4A]=sort([setxor(1:nb,exc_AC4A(:,1));exc_AC4A(:,1)]);
Tr_AC4A=exc_AC4A(:,2)';
kA_AC4A=exc_AC4A(:,3)';
TA_AC4A=exc_AC4A(:,4)';
TC_AC4A=exc_AC4A(:,5)';
TB_AC4A=exc_AC4A(:,6)';
VImax_AC4A=exc_AC4A(:,7)';
VImin_AC4A=exc_AC4A(:,8)';

VRmin_AC4A=exc_AC4A(:,9);
VRmax_AC4A=exc_AC4A(:,10);
KC_AC4A=exc_AC4A(:,11);

Efd0_AC4A=EFD0(exc_AC4A(:,1));

Vref_AC4A=Efd0_AC4A./kA_AC4A + lfl(exc_AC4A(:,1),2)';
Tgr0_AC4A=(Vref_AC4A - lfl(exc_AC4A(:,1),2)').*(1-TC_AC4A./TB_AC4A);
