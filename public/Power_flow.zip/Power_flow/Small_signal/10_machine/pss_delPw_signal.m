
%----Delta Power-Omega signal based PSS----
load delPw_pss.dat
%Modfy the delPw_pss to suit the enabled PSS
PSS_dash=~(PSS);
PSS_sm=PSS_dash(gen(:,1));
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
SL_delPw_pss_dash=~(SL_delPw_pss);
SL_delPw_pss_dash=SL_delPw_pss_dash(gen(:,1));
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PS2d=SL_delPw_pss_dash.*PSS_sm;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
npss1=sum(PS2d);
if (npss1~=0&npss1~=size(delPw_pss,1))
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
delPw_pss_temp=delPw_pss;
clear delPw_pss;
k=1;
for i=1:ngen
   if(PS2d(i)~=0)
      x(k)=gen(i,1);
      k=k+1;
   end
end
m=1;
for i=1:size(delPw_pss_temp,1)
   for np=1:npss1 
      if(delPw_pss_temp(i)==x(np))
         delPw_pss(m,:)=delPw_pss_temp(i,:);
         m=m+1;
      end
   end
end
%-------------------------------------------------------------------------------------
clear delPw_pss_temp;
end
[mm order_delPw_pss]=sort([setxor(1:nb,delPw_pss(:,1));delPw_pss(:,1)]);

Tm0_delPw=TmA0(delPw_pss(:,1)');
Tw1_delPw=delPw_pss(:,2)';
Tw2_delPw=delPw_pss(:,3)';
Tw3_delPw=delPw_pss(:,4)';
Tw4_delPw=delPw_pss(:,5)';
T6_delPw=delPw_pss(:,6)';
T7_delPw=delPw_pss(:,7)';
H_delPw=delPw_pss(:,8)';
Ks3_delPw=delPw_pss(:,9)';
T8_delPw=delPw_pss(:,10)';
T9_delPw=delPw_pss(:,11)';
T1_delPw=delPw_pss(:,12)';
T2_delPw=delPw_pss(:,13)';
T3_delPw=delPw_pss(:,14)';
T4_delPw=delPw_pss(:,15)';
Ks1_delPw=delPw_pss(:,16)';
VS_delPw_max=delPw_pss(:,17)';
VS_delPw_min=delPw_pss(:,18)';






