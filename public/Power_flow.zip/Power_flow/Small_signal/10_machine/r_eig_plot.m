%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
X5=('');
    for i=1:size(n_slip_V,1)
         X5=strvcat(X5,'SG-');
     end
  XGN=num2str(par_gen_num);     
  XGEN=strcat(X5,XGN);
   
  %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  col=['r','b','m','k','g','c'];
  num_r_eig=6;
  nplts=fix(size(n_slip_V,1)/num_r_eig);
  delete(get(0,'children'))
  for p=1:nplts+1
     figure(p)
     cl=1;
     for k=1:num_r_eig
        if ((size(n_slip_V,1)-num_r_eig*(p-1))>=k)
        compass(n_slip_V(k+num_r_eig*(p-1)),col(cl));
        gtext({XGEN(k+num_r_eig*(p-1),:)});
            if(cl==1)
                hold
              end
             cl=cl+1;
          end
       end
    end  