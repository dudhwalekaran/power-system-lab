MATLAB/SIMULINK-BASED  MULTI-MACHINE SMALL-SIGNAL STABILITY PROGRAMMES
------------------------------------------------------------------
Main folder name: Small_signal

The following are the features of the programme:

1. Full-blown model (2.2 model) for  synchronous machines.
2. Permits any simplified models, even classical model for generators.
3. Three IEEE-type exciters: Single-time constant static type, DC1A-type and AC4A-type.
4. Two IEEE-type turbine systems with the associated speed governor systems: Hydro and single-reheat type.
5. Three IEEE-type Power System Stabilizers (PSS): Slip-signal, delta-P-Omega and power-signal type.
6. Flexibility to use any kind of exciter/PSS/turbine with a given generator.
7. Voltage-dependent static load models.
8. No restriction on the size of the system.
9. The programme can identify swing/non-swing modes and their association with state variables.
10.Graphical visualization of swing modes.
11. Analytical determination of GEPS(s) and interactive design of PSS. 
12. Time-domain verification of small/large-signal behaviour without separate data file preparation.
13. Provision to perturb Vref  of any machine.
14. Provision to carry out power ramping studies for any machine.
   
Sub folders provided:

a) 4_machine: Contains files related to 4 machine, 10 bus power system.
   gen.dat  : 2.2 model
   gen11.dat: 1.1 model (rename it as gen.dat for making it active.)
   gen00.dat: classical model (rename it as gen.dat for making it active.)
  (Adopted from the book 'Power System Dynamics-Stability and Control' by K.R. Padiyar.)

b) 50_machine: Contains files related to 50 machine, 145 bus, IEEE power system. 

c) smib: Contains files related to the example 6.6 in the book 'Power System  
   Dynamics-Stability and Control' by K.R. Padiyar.

d) 10_machine: Adopted from the book 'Power System Dynamics-Stability and Control' by K.R. Padiyar.

e) manual_SSS.pdf: Manual for small-signal stability programme.
------------------------------------------------------------------------------------
