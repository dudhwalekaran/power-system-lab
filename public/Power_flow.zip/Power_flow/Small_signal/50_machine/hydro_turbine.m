%speed Governer system with Hydro Turbine.
load turb_hydro.dat
[mm order_hydro]=sort([setxor(1:nb,turb_hydro(:,1)) turb_hydro(:,1)]);
T_wht=turb_hydro(:,2)';
TG_ht=turb_hydro(:,3)';
% sig_ht -Regulation on system base= R(on m/c base)*100/P_base of m/c
sig_ht=turb_hydro(:,4)'; 
T2_ht=turb_hydro(:,5)';
Pgv_ht_max=turb_hydro(:,6)';
Pgv_ht_min=turb_hydro(:,7)';

TR_ht= 5*T_wht;
beta_ht=1.25*T_wht./H_a(turb_hydro(:,1));
TA_ht=(1./sig_ht).*TR_ht.*TG_ht;
TB_ht=(1./sig_ht).*((beta_ht+sig_ht).*TR_ht + TG_ht);
T1_ht=TB_ht/2+ sqrt(TB_ht.^2/4-TA_ht);
T3_ht=TB_ht/2-sqrt(TB_ht.^2/4-TA_ht);
K_ht=1./sig_ht;

Tm0_hydr0=TmA0(turb_hydro(:,1));
Pgv_ht0=Tm0_hydr0;

Tgr_ht0=(1-(-T_wht)./(0.5*T_wht)).*Pgv_ht0;
