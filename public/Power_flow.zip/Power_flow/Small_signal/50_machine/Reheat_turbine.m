%Speed governer with reheat type turbine

load turb_rhst.dat
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[mm order_rhst]=sort([setxor(1:nb,turb_rhst(:,1)) turb_rhst(:,1)]);
T1_rht=turb_rhst(:,2)';
T2_rht=turb_rhst(:,3)';
T3_rht=turb_rhst(:,4)';
sig_rht=turb_rhst(:,5)';
Pgv_rht_max=turb_rhst(:,6)';
Pgv_rht_min=turb_rhst(:,7)';
TCH_rht=turb_rhst(:,8)';
TRH_rht=turb_rhst(:,9)';
TCO_rht=turb_rhst(:,10)';
FHP_rht=turb_rhst(:,11)';
FIP_rht=turb_rhst(:,12)';
FLP_rht=turb_rhst(:,13)';

K_rht=1./sig_rht;
Pgv_rht0=TmA0(turb_rhst(:,1));
HP_rht0=Pgv_rht0;
IP_rht0=Pgv_rht0;
LP_rht0=Pgv_rht0;
