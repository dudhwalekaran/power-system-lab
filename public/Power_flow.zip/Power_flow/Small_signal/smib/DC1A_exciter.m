%------------------------IEEE type-1 Exciters-------------------
load exc_DC1A.dat;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[mm order_DC1A]=sort([setxor(1:nb,exc_DC1A(:,1)),exc_DC1A(:,1)']);
Tr_DC1A=exc_DC1A(:,2)';
KA_DC1A=exc_DC1A(:,3)';
TA_DC1A=exc_DC1A(:,4)';
TC_DC1A=exc_DC1A(:,5)';
TB_DC1A=exc_DC1A(:,6)';
VRmax_DC1A=exc_DC1A(:,7)';
VRmin_DC1A=exc_DC1A(:,8)';
KE_DC1A=exc_DC1A(:,9)';
TE_DC1A=exc_DC1A(:,10)';
E1=exc_DC1A(:,11)';
SE1=exc_DC1A(:,12)';
E2=exc_DC1A(:,13)';
SE2=exc_DC1A(:,14)';
KF_DC1A=exc_DC1A(:,15)';
TF_DC1A=exc_DC1A(:,16)';

Efd0_DC1A=EFD0(exc_DC1A(:,1));

%calculation of saturation function coef., A and B in  SE=A*exp(B*Efd)
B_DC1A=(1./(E1-E2)).*log(SE1./SE2);
A_DC1A=SE1./(exp(B_DC1A.*E1));

VR0_DC1A=(A_DC1A.*exp(B_DC1A.*Efd0_DC1A)+KE_DC1A).*Efd0_DC1A;
Vref_DC1A=VR0_DC1A./KA_DC1A + lfl(exc_DC1A(:,1),2)';
Fst0_DC1A=Efd0_DC1A.*KF_DC1A;
Tgr0_DC1A=(Vref_DC1A - lfl(exc_DC1A(:,1),2)').*(1-TC_DC1A./TB_DC1A);
