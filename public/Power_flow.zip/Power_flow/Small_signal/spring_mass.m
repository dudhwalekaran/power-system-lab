clear all
%Parameters for 3-mass, 2-spring system
k12=2;
k23=20;
m1=10;
m2=1;
m3=1;
Am=[0 0 -1 1 0
   0 0 -1 0 1
   (k12/m1) 0 0 0 0
   (-k12/m2-k23/m2) k23/m2 0 0 0
   k23/m3 -k23/m3 0 0 0];
[U D]=eig(Am);
d=diag(D)
W=inv(U)
P=U.*conj(W')
%initial value of states for case-1, case-2 and case-3 rspectively
%x1=[-1 -1 0 0 0]';
%x1=[1 0 0 0 0]';
x1=[0 0 1 0 0]';

